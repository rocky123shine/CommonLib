package com.rocky.commonlib.test;

public class AndroidVersionBean {


    @Override
    public String toString() {
        return "AndroidVersionBean{" +
                "version=" + version +
                ", site_url='" + site_url + '\'' +
                '}';
    }

    /**
     * version : {"version_id":"1","version_code":"1.0.0","version_content":"安卓上线","is_force":"1","type":"1"}
     * site_url : http://www.jingjing.shop/
     */

    private VersionBean version;
    private String site_url;

    public VersionBean getVersion() {
        return version;
    }

    public void setVersion(VersionBean version) {
        this.version = version;
    }

    public String getSite_url() {
        return site_url;
    }

    public void setSite_url(String site_url) {
        this.site_url = site_url;
    }

    public static class VersionBean {
        /**
         * version_id : 1
         * version_code : 1.0.0
         * version_content : 安卓上线
         * is_force : 1
         * type : 1
         */

        private String version_id;
        private String version_code;
        private String version_content;
        private String is_force;
        private String type;

        @Override
        public String toString() {
            return "VersionBean{" +
                    "version_id='" + version_id + '\'' +
                    ", version_code='" + version_code + '\'' +
                    ", version_content='" + version_content + '\'' +
                    ", is_force='" + is_force + '\'' +
                    ", type='" + type + '\'' +
                    '}';
        }

        public String getVersion_id() {
            return version_id;
        }

        public void setVersion_id(String version_id) {
            this.version_id = version_id;
        }

        public String getVersion_code() {
            return version_code;
        }

        public void setVersion_code(String version_code) {
            this.version_code = version_code;
        }

        public String getVersion_content() {
            return version_content;
        }

        public void setVersion_content(String version_content) {
            this.version_content = version_content;
        }

        public String getIs_force() {
            return is_force;
        }

        public void setIs_force(String is_force) {
            this.is_force = is_force;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }
    }
}
