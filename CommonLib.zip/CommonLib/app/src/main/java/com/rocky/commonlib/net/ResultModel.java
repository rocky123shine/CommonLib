package com.rocky.commonlib.net;

/**
 * @author
 * @date 2019/12/6.
 * description：
 */
public class ResultModel<T> extends BaseResultModel {
    public T result;
}
