package com.rocky.commonlib.net;

/**
 * @author
 * @date 2019/12/6.
 * description：
 */
public class BaseResultModel {
    public String code;
    public String message;
}
