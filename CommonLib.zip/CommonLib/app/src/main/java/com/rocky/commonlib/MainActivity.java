package com.rocky.commonlib;

import android.widget.TextView;

import com.rocky.commonlib.base.BaseActivity;
import com.rocky.commonlib.net.ApiService;
import com.rocky.commonlib.net.CommonObserver;
import com.rocky.commonlib.net.RequestUtitl;
import com.rocky.commonlib.net.ResultModel;
import com.rocky.commonlib.test.AndroidVersionBean;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends BaseActivity {

    private TextView tv_result;

    @Override
    protected int setContentLayout() {
        return R.layout.activity_main;
    }

    @Override
    protected void init() {
        super.init();
        tv_result = findViewById(R.id.tv_result);
        Map<String, Object> map = new HashMap<>();
        map.put("type", "1");

        RequestUtitl.getInstance().request(ApiService.getInstance().createVersionService().getVersion(map),
                this.<ResultModel<AndroidVersionBean>>bindToLifecycle(), new CommonObserver<AndroidVersionBean>() {
                    @Override
                    public void onNext(AndroidVersionBean androidVersionBean) {
                        super.onNext(androidVersionBean);
                        tv_result.setText(androidVersionBean.getVersion().getVersion_code() + "-------" + androidVersionBean.getVersion().getVersion_content());
                    }
                }, AndroidVersionBean.class);

    }
}
