package com.rocky.commonlib.base;

/**
 * @author
 * @date 2019/12/6.
 * description：
 */
public class BaseEvent {
}
