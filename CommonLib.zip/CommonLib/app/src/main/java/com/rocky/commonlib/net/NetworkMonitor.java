package com.rocky.commonlib.net;

public interface NetworkMonitor {
    boolean isConnected();
}