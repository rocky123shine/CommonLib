package com.rocky.commonlib.test;

import com.rocky.commonlib.net.ResultModel;

import java.util.Map;

import io.reactivex.Observable;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * @author
 * @date 2019/12/6.
 * description：
 */
public interface VersionService {
    @FormUrlEncoded
    @POST("index.php?m=Home&c=Version&a=index")
    Observable<ResultModel<AndroidVersionBean>> getVersion(@FieldMap Map<String, Object> map);
}
