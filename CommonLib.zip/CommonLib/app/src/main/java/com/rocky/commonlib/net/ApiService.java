package com.rocky.commonlib.net;

import com.rocky.commonlib.test.VersionService;

import retrofit2.Retrofit;

/**
 * @author
 * @date 2019/12/6.
 * description：
 */
public class ApiService {

    private static ApiService ourInstance = null;

    public static ApiService getInstance() {
        if (ourInstance == null) {
            synchronized (RequestUtitl.class) {
                if (ourInstance == null) {
                    ourInstance = new ApiService();
                }
            }
        }
        return ourInstance;
    }

    private ApiService() {
    }

    private Retrofit retrofit() {
        return NetWork.getInstance().retrofit();
    }

    public VersionService createVersionService() {
        return retrofit().create(VersionService.class);
    }
}
