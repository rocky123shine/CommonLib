package com.rocky.commonlib.net;


import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

/**
 * @author
 * @date 2019/12/6.
 * description：
 */
public abstract class CommonObserver<T> implements Observer<T> {
    @Override
    public void onComplete() {

    }

    @Override
    public void onSubscribe(Disposable d) {

    }

    @Override
    public void onNext(T t) {
        if (t == null) {
            onError(new NullPointerException("onNext called with null. Null values are generally not allowed in 2.x operators and sources."));
        }
    }

    @Override
    public void onError(Throwable e) {

    }

}
