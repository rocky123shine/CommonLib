package com.rocky.commonlib.base.adapter.util;

import java.util.List;


public interface OnValueChangeListener {
    void onValueChanged(List<Object> list);
}
