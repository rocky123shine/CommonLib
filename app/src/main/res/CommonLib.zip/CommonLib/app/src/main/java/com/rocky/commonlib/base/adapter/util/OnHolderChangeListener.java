package com.rocky.commonlib.base.adapter.util;


import com.rocky.commonlib.base.adapter.holder.BaseViewHolder;

public interface OnHolderChangeListener {
    void onHolderChange(BaseViewHolder viewHolder);
}
