package com.rocky.commonlib;

import com.rocky.commonlib.base.BaseActivity;

public class MainActivity extends BaseActivity {


    @Override
    protected int setContentLayout() {
        return R.layout.activity_main;
    }

    @Override
    protected void init() {
        super.init();
//        Map<String, Object> map = new HashMap<>();
//        map.put("type", "1");

//        RequestUtitl.getInstance().request(
//                NetWork.getInstance().retrofit().create(VersionService.class).getVersion(map),
//                this.<ResultModel<AndroidVersionBean>>bindToLifecycle(),
//                new CommonObserver<AndroidVersionBean>() {
//                    @Override
//                    public void onNext(AndroidVersionBean androidVersionBean) {
//                        super.onNext(androidVersionBean);
//                        tv_result.setText(androidVersionBean.getVersion().toString());
//                    }
//                },
//                AndroidVersionBean.class);

    }


}
