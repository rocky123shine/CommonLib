package com.rocky.commonlib.base.event;

/**
 * @author
 * @date 2019/12/6.
 * description：
 */
public class BaseEvent {
}
